<div class="grid grid-cols-1 gap-4 md:grid-cols-2" data-master-fields-grid>
    <?php $__currentLoopData = $config['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($field['type'] === 'checkbox'): ?>
            <label data-field-wrap="<?php echo e($field['name']); ?>" data-create-hidden="<?php echo e(!empty($field['create_hidden']) ? '1' : '0'); ?>" class="<?php echo e(!empty($field['wide']) ? 'md:col-span-2' : ''); ?> flex items-center gap-3 border border-slate-200 bg-slate-50 p-3 font-bold text-slate-700">
                <input type="checkbox" name="<?php echo e($field['name']); ?>" value="1" data-master-field="<?php echo e($field['name']); ?>" <?php if($field['default'] ?? ($field['name'] === 'is_active')): echo 'checked'; endif; ?> class="h-5 w-5">
                <?php echo e($field['label']); ?>

            </label>
        <?php else: ?>
            <label data-field-wrap="<?php echo e($field['name']); ?>" data-create-hidden="<?php echo e(!empty($field['create_hidden']) ? '1' : '0'); ?>" class="<?php echo e(!empty($field['wide']) ? 'md:col-span-2' : ''); ?>">
                <span class="mb-1 block text-xs font-black uppercase tracking-wide text-slate-600"><?php echo e($field['label']); ?> <?php if(!empty($field['required'])): ?><span class="text-red-600">*</span><?php endif; ?></span>
                <?php if($field['type'] === 'textarea'): ?>
                    <textarea name="<?php echo e($field['name']); ?>" data-master-field="<?php echo e($field['name']); ?>" data-default-value="<?php echo e($field['default'] ?? ''); ?>" class="master-textarea quick-master-textarea" <?php echo e(!empty($field['required']) ? 'required' : ''); ?>><?php echo e($field['default'] ?? ''); ?></textarea>
                <?php elseif($field['type'] === 'select'): ?>
                    <select name="<?php echo e($field['name']); ?>" data-master-field="<?php echo e($field['name']); ?>" class="master-input quick-master-input" <?php echo e(!empty($field['required']) ? 'required' : ''); ?>>
                        <option value="">Select <?php echo e($field['label']); ?></option>
                        <?php $__currentLoopData = ($field['options'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <input type="<?php echo e($field['type']); ?>" name="<?php echo e($field['name']); ?>" data-master-field="<?php echo e($field['name']); ?>" class="master-input quick-master-input" <?php if($field['type'] === 'number'): ?> step="0.01" <?php endif; ?> <?php echo e(!empty($field['required']) ? 'required' : ''); ?>>
                <?php endif; ?>
            </label>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\laragon\www\transportsb\resources\views/masters/partials/form-fields.blade.php ENDPATH**/ ?>