<?php $__env->startSection('title', 'Bank | XYZ Transport'); ?>
<?php $__env->startSection('page-nav-target', '#nav-payments'); ?>

<?php $__env->startPush('styles'); ?>
<style>
.bank-card{border:1px solid #cbd5e1;background:#fff}.bank-input{height:38px;width:100%;border:1px solid #94a3b8;background:#fff;padding:0 9px;outline:none;font-weight:700}.bank-input:focus{border-color:#047857;box-shadow:0 0 0 2px #d1fae5}.bank-table{width:100%;border-collapse:collapse;font-size:12px}.bank-table th{background:#dfe7f1;border:1px solid #aebccd;padding:7px 8px;font-size:10px;font-weight:900;text-transform:uppercase}.bank-table td{border:1px solid #cbd5e1;padding:8px}.bank-table tbody tr:hover td{background:#f8fafc}.bank-num{text-align:right;font-variant-numeric:tabular-nums}.bank-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px}.bank-summary>div{border:1px solid #cbd5e1;background:#f8fafc;padding:10px}.bank-summary small{display:block;font-size:10px;font-weight:900;text-transform:uppercase;color:#64748b}.bank-summary b{display:block;margin-top:2px;font-size:16px}.bank-modal{position:fixed;inset:0;z-index:230;background:rgba(15,23,42,.58);display:flex;align-items:center;justify-content:center;padding:16px}.bank-modal.hidden{display:none!important}.bank-modal-card{width:min(680px,96vw);background:#fff;border:1px solid #64748b;box-shadow:0 24px 70px rgba(15,23,42,.35)}.bank-modal-head{display:flex;align-items:center;justify-content:space-between;background:#055b46;color:#fff;padding:11px 16px}.bank-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.bank-field label{display:block;margin-bottom:4px;font-size:10px;font-weight:900;text-transform:uppercase;color:#475569}.bank-field.full{grid-column:1/-1}.cash-effect-box{grid-column:1/-1;display:flex;align-items:flex-start;gap:10px;border:1px solid #cbd5e1;background:#f8fafc;padding:10px 12px}.cash-effect-box input{width:18px;height:18px;margin-top:1px}.cash-effect-box b{display:block;font-size:12px}.cash-effect-box small{display:block;margin-top:2px;color:#64748b;font-weight:700}.bank-btn{height:38px;border:1px solid #94a3b8;background:#fff;padding:0 14px;font-weight:900}.bank-btn.primary{border-color:#08765b;background:#08765b;color:#fff}.previous-row td{background:#fff9c4!important;font-weight:900}.balance-positive{color:#047857}.balance-negative{color:#b91c1c}.bank-empty{padding:45px 10px;text-align:center;color:#94a3b8;font-weight:700}@media(max-width:800px){.bank-summary{grid-template-columns:1fr 1fr}.bank-grid{grid-template-columns:1fr}.bank-field.full{grid-column:auto}}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-workspace bank-card">
    <div class="flex flex-wrap items-end gap-3 border-b border-slate-300 bg-slate-50 p-4">
        <div class="mr-auto">
            <h1 class="text-xl font-black">Bank Transactions</h1>
            <p class="mt-1 text-xs font-semibold text-slate-500">Deposit = Credit · Withdrawal = Debit · newest transaction is shown first.</p>
        </div>
        <button type="button" id="openBankTransaction" class="h-10 bg-emerald-800 px-5 text-sm font-black text-white">+ Add Transaction</button>
    </div>

    <form method="GET" action="<?php echo e(route('payments.bank.index')); ?>" class="flex flex-wrap items-end gap-2 border-b border-slate-300 p-4">
        <label class="w-40"><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">From Date</span><input type="date" name="from_date" value="<?php echo e($fromDate); ?>" class="bank-input"></label>
        <label class="w-40"><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">To Date</span><input type="date" name="to_date" value="<?php echo e($toDate); ?>" class="bank-input"></label>
        <label class="min-w-[260px] flex-1 max-w-md"><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Bank</span>
            <select name="bank_id" class="bank-input">
                <option value="">Select Bank</option>
                <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bank->id); ?>" <?php if((string)$bankId === (string)$bank->id): echo 'selected'; endif; ?>><?php echo e($bank->name); ?><?php echo e($bank->is_active ? '' : ' (Inactive)'); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <button class="bank-btn primary">Show</button>
        <a href="<?php echo e(route('payments.bank.index')); ?>" class="bank-btn inline-flex items-center">Reset</a>
    </form>

    <?php if($selectedBank): ?>
    <div class="p-4">
        <div class="mb-3 flex flex-wrap items-center justify-between gap-3">
            <div><span class="text-xs font-black uppercase text-slate-500">Company / Bank</span><div class="text-lg font-black"><?php echo e($selectedBank->company?->name ? $selectedBank->company->name.' · ' : ''); ?><?php echo e($selectedBank->name); ?></div></div>
            <div class="text-right"><span class="text-xs font-black uppercase text-slate-500">Balance as on <?php echo e(\Carbon\Carbon::parse($toDate)->format('d-m-Y')); ?></span><div class="text-xl font-black <?php echo e($currentBalance < 0 ? 'balance-negative' : 'balance-positive'); ?>">₹<?php echo e(number_format($currentBalance,2)); ?></div></div>
        </div>

        <div class="bank-summary mb-4">
            <div><small>Previous Balance</small><b>₹<?php echo e(number_format($previousBalance,2)); ?></b></div>
            <div><small>Period Credit / Deposit</small><b class="text-emerald-700">₹<?php echo e(number_format($periodCredit,2)); ?></b></div>
            <div><small>Period Debit / Withdrawal</small><b class="text-red-700">₹<?php echo e(number_format($periodDebit,2)); ?></b></div>
            <div><small>Closing Balance</small><b class="<?php echo e($currentBalance < 0 ? 'balance-negative' : 'balance-positive'); ?>">₹<?php echo e(number_format($currentBalance,2)); ?></b></div>
        </div>

        <div class="overflow-auto">
            <table class="bank-table">
                <thead><tr><th style="width:55px">Sr</th><th style="width:120px">Date</th><th>Particular</th><th style="width:155px">Debit</th><th style="width:155px">Credit</th><th style="width:170px">Balance</th><th>Remarks</th><th style="width:80px">Delete</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($i + 1); ?></td>
                        <td class="font-bold"><?php echo e($row['transaction_date']); ?></td>
                        <td class="font-black"><?php echo e($row['particular']); ?></td>
                        <td class="bank-num text-red-700"><?php echo e($row['debit'] > 0 ? '₹'.number_format($row['debit'],2) : '-'); ?></td>
                        <td class="bank-num text-emerald-700"><?php echo e($row['credit'] > 0 ? '₹'.number_format($row['credit'],2) : '-'); ?></td>
                        <td class="bank-num font-black <?php echo e($row['balance'] < 0 ? 'balance-negative' : ''); ?>">₹<?php echo e(number_format($row['balance'],2)); ?></td>
                        <td><?php echo e($row['remarks'] ?: '-'); ?></td>
                        <td class="text-center"><?php if(!empty($row['source_type'])): ?><span class="text-[10px] font-bold text-slate-400">Auto</span><?php else: ?><form method="POST" action="<?php echo e(route('payments.bank.destroy', $row['id'])); ?>" onsubmit="return confirm('Delete this bank transaction?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="font-bold text-red-700 hover:underline">Delete</button></form><?php endif; ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="8" class="bank-empty">No bank transactions found for the selected date range.</td></tr>
                <?php endif; ?>
                    <tr class="previous-row"><td colspan="5" class="text-right">Previous Balance</td><td class="bank-num">₹<?php echo e(number_format($previousBalance,2)); ?></td><td colspan="2">Before <?php echo e(\Carbon\Carbon::parse($fromDate)->format('d-m-Y')); ?></td></tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php else: ?>
        <div class="bank-empty">Select a bank to view its transaction ledger. <?php if($banks->isEmpty()): ?>First create a bank from Masters → Bank Master.<?php endif; ?></div>
    <?php endif; ?>
</div>

<div id="bankTransactionModal" class="bank-modal hidden" role="dialog" aria-modal="true">
    <div class="bank-modal-card">
        <div class="bank-modal-head"><h2 class="font-black">Add Bank Transaction</h2><button type="button" id="closeBankTransaction" class="text-2xl">×</button></div>
        <form id="bankTransactionForm" method="POST" action="<?php echo e(route('payments.bank.store')); ?>" class="p-4"><?php echo csrf_field(); ?>
            <input type="hidden" name="from_date" value="<?php echo e($fromDate); ?>">
            <input type="hidden" name="to_date" value="<?php echo e($toDate); ?>">
            <div class="bank-grid">
                <div class="bank-field full"><label for="transactionBank">Bank *</label>
                    <?php ($defaultBankId = old('bank_id', $activeBanks->count() === 1 ? $activeBanks->first()->id : ($selectedBank?->is_active ? $selectedBank->id : ''))); ?>
                    <select id="transactionBank" name="bank_id" class="bank-input" required>
                        <option value="">Select Bank</option>
                        <?php $__currentLoopData = $activeBanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bank->id); ?>" <?php if((string)$defaultBankId === (string)$bank->id): echo 'selected'; endif; ?>><?php echo e($bank->company?->name ? $bank->company->name.' · ' : ''); ?><?php echo e($bank->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="bank-field"><label for="transactionDate">Payment Date *</label><input id="transactionDate" type="date" name="transaction_date" value="<?php echo e(old('transaction_date', now()->toDateString())); ?>" class="bank-input" required></div>
                <div class="bank-field"><label for="transactionType">Type *</label><select id="transactionType" name="type" class="bank-input" required><option value="deposit" <?php if(old('type','deposit')==='deposit'): echo 'selected'; endif; ?>>Deposit</option><option value="withdraw" <?php if(old('type')==='withdraw'): echo 'selected'; endif; ?>>Withdraw</option></select></div>
                <div class="bank-field"><label for="transactionAmount">Amount *</label><input id="transactionAmount" type="number" min="0.01" step="0.01" name="amount" value="<?php echo e(old('amount')); ?>" class="bank-input bank-num" placeholder="0.00" required></div>

                <label class="cash-effect-box">
                    <input
                        id="affectCashInHand"
                        type="checkbox"
                        name="affect_cash_in_hand"
                        value="1"
                        <?php if(old('affect_cash_in_hand', '1')): echo 'checked'; endif; ?>
                    >
                    <span>
                        <b>Affect Cash in Hand</b>
                        <small>Checked by default. Deposit reduces Cash in Hand; Withdrawal increases Cash in Hand.</small>
                    </span>
                </label>

                <div class="bank-field full"><label for="transactionRemarks">Remarks</label><input id="transactionRemarks" name="remarks" value="<?php echo e(old('remarks')); ?>" maxlength="500" class="bank-input" autocomplete="off"></div>
            </div>
            <div class="mt-2 text-right text-xs font-semibold text-slate-500">Enter: Bank → Date → Type → Amount → Remarks → Save · Ctrl+S Save · Esc Close</div>
            <div class="mt-4 flex justify-end gap-2"><button type="button" id="cancelBankTransaction" class="bank-btn">Cancel</button><button type="submit" class="bank-btn primary">Save Transaction</button></div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded',()=>{
    const modal=document.getElementById('bankTransactionModal'),openBtn=document.getElementById('openBankTransaction'),closeBtn=document.getElementById('closeBankTransaction'),cancelBtn=document.getElementById('cancelBankTransaction'),form=document.getElementById('bankTransactionForm');
    const bank=document.getElementById('transactionBank'),date=document.getElementById('transactionDate'),type=document.getElementById('transactionType'),amount=document.getElementById('transactionAmount'),remarks=document.getElementById('transactionRemarks');
    let opener=null;
    const fields=[bank,date,type,amount,remarks].filter(Boolean);
    function openModal(origin=openBtn){opener=origin||document.activeElement;modal.classList.remove('hidden');document.body.style.overflow='hidden';setTimeout(()=>bank?.focus(),25);}
    function closeModal(){modal.classList.add('hidden');document.body.style.overflow='';const back=opener;opener=null;setTimeout(()=>back?.focus?.(),0);}
    openBtn?.addEventListener('click',()=>openModal(openBtn));closeBtn?.addEventListener('click',closeModal);cancelBtn?.addEventListener('click',closeModal);modal?.addEventListener('mousedown',e=>{if(e.target===modal)closeModal();});
    form?.addEventListener('keydown',e=>{
        if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closeModal();return;}
        if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();form.requestSubmit();return;}
        if(e.key!=='Enter')return;
        const i=fields.indexOf(e.target);if(i<0)return;e.preventDefault();
        if(e.target===date&&!date.value){date.showPicker?.();return;}
        if(i<fields.length-1){fields[i+1].focus();if(fields[i+1] instanceof HTMLInputElement)fields[i+1].select?.();}else form.requestSubmit();
    });
    <?php if($errors->any()): ?> openModal(document.activeElement); <?php endif; ?>
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\transportsb\resources\views/payments/bank.blade.php ENDPATH**/ ?>