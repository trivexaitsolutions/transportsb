<?php $__env->startSection('title', 'Company Master | XYZ Transport'); ?>
<?php $__env->startSection('page-nav-target', '#nav-masters'); ?>

<?php $__env->startPush('styles'); ?>
<style>
.company-card{border:1px solid #cbd5e1;background:#fff;box-shadow:0 1px 2px rgba(15,23,42,.05)}
.company-table{width:100%;border-collapse:collapse;font-size:.86rem}
.company-table th{background:#f1f5f9;border-bottom:1px solid #94a3b8;padding:.65rem .75rem;text-align:left;font-size:.72rem;text-transform:uppercase;color:#475569;white-space:nowrap}
.company-table td{border-bottom:1px solid #e2e8f0;padding:.62rem .75rem;vertical-align:top}
.company-table tr:hover td,.company-table tr:focus td{background:#ecfdf5}
.company-input,.company-textarea{width:100%;border:1px solid #94a3b8;background:#fff;padding:0 .65rem;outline:none}
.company-input{height:2.5rem}.company-textarea{min-height:95px;padding:.65rem;resize:vertical}
.company-input:focus,.company-textarea:focus{border-color:#047857;box-shadow:0 0 0 2px #d1fae5}
.company-modal{position:fixed;inset:0;z-index:220;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:1rem}
.company-modal.hidden{display:none!important}.company-modal-card{width:min(720px,96vw);max-height:92vh;overflow:auto;background:#fff;border:1px solid #64748b;box-shadow:0 24px 70px rgba(15,23,42,.35)}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-workspace">
    <div class="mb-4 flex flex-wrap items-end gap-3">
        <div class="mr-auto">
            <h1 class="text-xl font-black text-slate-950">Company Master</h1>
            <p class="mt-1 text-sm font-medium text-slate-500">Maintain the legal company details used later in Voucher, Billing, Bank and Payment flows.</p>
        </div>

        <form method="GET" class="flex items-center gap-2">
            <input name="search" value="<?php echo e($search); ?>" class="company-input w-72" placeholder="Search name / GST / address...">
            <button class="h-10 border border-slate-400 bg-white px-4 text-sm font-bold hover:bg-slate-50">Search</button>
            <?php if($search): ?>
                <a href="<?php echo e(route('masters.companies.index')); ?>" class="h-10 border border-slate-300 px-4 py-2 text-sm font-bold text-slate-600">Clear</a>
            <?php endif; ?>
        </form>

        <button type="button" id="addCompanyBtn" class="h-10 bg-emerald-800 px-5 text-sm font-bold text-white hover:bg-emerald-900">+ Add Company</button>
    </div>

    <div class="mb-3 border border-blue-200 bg-blue-50 px-4 py-3 text-sm font-semibold text-blue-900">
        Existing BGT / LST Transport Names are not changed in this phase. They will be mapped to Company Master in the next phase.
    </div>

    <div class="company-card overflow-x-auto">
        <table class="company-table">
            <thead>
                <tr>
                    <th style="width:70px">Sr</th>
                    <th>Company Name</th>
                    <th style="width:230px">GST Number</th>
                    <th>Company Address</th>
                    <th style="width:150px" class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr tabindex="0" data-company-row>
                    <td><?php echo e(($items->currentPage()-1)*$items->perPage()+$loop->iteration); ?></td>
                    <td class="font-black"><?php echo e($item->name); ?></td>
                    <td class="font-bold"><?php echo e($item->gst_no); ?></td>
                    <td class="whitespace-pre-line"><?php echo e($item->address); ?></td>
                    <td class="whitespace-nowrap text-right">
                        <button
                            type="button"
                            class="edit-company font-bold text-blue-700 hover:underline"
                            data-id="<?php echo e($item->id); ?>"
                            data-record="<?php echo e(json_encode([
                                'name' => $item->name,
                                'gst_no' => $item->gst_no,
                                'address' => $item->address,
                            ])); ?>"
                        >Edit</button>

                        <form method="POST" action="<?php echo e(route('masters.companies.destroy', $item)); ?>" class="ml-3 inline" onsubmit="return confirm('Delete this company?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="font-bold text-red-700 hover:underline">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="py-10 text-center text-slate-400">No companies added yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4"><?php echo e($items->links()); ?></div>
</div>

<div id="companyModal" class="company-modal hidden" role="dialog" aria-modal="true">
    <div class="company-modal-card">
        <div class="flex items-center justify-between bg-emerald-950 px-5 py-3 text-white">
            <h2 id="companyModalTitle" class="font-black">Add Company</h2>
            <button type="button" id="companyCloseBtn" class="text-2xl">×</button>
        </div>

        <form id="companyForm" method="POST" action="<?php echo e(route('masters.companies.store')); ?>" class="p-5">
            <?php echo csrf_field(); ?>
            <div id="companyMethodSlot"></div>

            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                <label class="md:col-span-2">
                    <span class="mb-1 block text-xs font-black uppercase text-slate-600">Company Name <span class="text-red-600">*</span></span>
                    <input name="name" data-company-field="name" class="company-input" maxlength="150" required>
                </label>

                <label class="md:col-span-2">
                    <span class="mb-1 block text-xs font-black uppercase text-slate-600">GST Number <span class="text-red-600">*</span></span>
                    <input name="gst_no" data-company-field="gst_no" class="company-input uppercase" maxlength="30" required>
                </label>

                <label class="md:col-span-2">
                    <span class="mb-1 block text-xs font-black uppercase text-slate-600">Company Address <span class="text-red-600">*</span></span>
                    <textarea name="address" data-company-field="address" class="company-textarea" maxlength="2000" required></textarea>
                </label>
            </div>

            <div class="mt-5 flex justify-end gap-2">
                <button type="button" id="companyCancelBtn" class="border border-slate-400 px-5 py-2.5 text-sm font-bold">Cancel</button>
                <button type="submit" class="bg-emerald-800 px-6 py-2.5 text-sm font-black text-white">Save Company</button>
            </div>

            <div class="mt-2 text-right text-xs font-semibold text-slate-500">Insert = Add · Enter = Next · Ctrl+S = Save · Esc = Close</div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('companyModal');
    const form = document.getElementById('companyForm');
    const title = document.getElementById('companyModalTitle');
    const methodSlot = document.getElementById('companyMethodSlot');
    const addBtn = document.getElementById('addCompanyBtn');
    const storeUrl = <?php echo json_encode(route('masters.companies.store'), 15, 512) ?>;
    const baseUrl = <?php echo json_encode(url('/masters/companies'), 15, 512) ?>;
    let opener = null;

    const field = name => form.querySelector(`[data-company-field="${name}"]`);
    const orderedFields = () => Array.from(form.querySelectorAll('[data-company-field]'));

    function resetForm() {
        form.reset();
        form.action = storeUrl;
        methodSlot.innerHTML = '';
    }

    function openCreate(origin = addBtn) {
        opener = origin || document.activeElement;
        resetForm();
        title.textContent = 'Add Company';
        modal.classList.remove('hidden');
        setTimeout(() => field('name').focus(), 20);
    }

    function openEdit(button) {
        opener = button;
        let record = {};

        try {
            record = JSON.parse(button.dataset.record || '{}');
        } catch (e) {
            window.AppToast?.('Unable to open this company. Please refresh and try again.', 'error');
            return;
        }

        resetForm();
        form.action = baseUrl + '/' + button.dataset.id;
        methodSlot.innerHTML = '<input type="hidden" name="_method" value="PUT">';
        title.textContent = 'Edit Company';

        field('name').value = record.name || '';
        field('gst_no').value = record.gst_no || '';
        field('address').value = record.address || '';

        modal.classList.remove('hidden');
        setTimeout(() => field('name').focus(), 20);
    }

    function closeModal() {
        modal.classList.add('hidden');
        const previous = opener;
        opener = null;
        setTimeout(() => previous?.focus?.(), 0);
    }

    addBtn.addEventListener('click', () => openCreate(addBtn));
    document.querySelectorAll('.edit-company').forEach(button => button.addEventListener('click', () => openEdit(button)));
    document.getElementById('companyCloseBtn').addEventListener('click', closeModal);
    document.getElementById('companyCancelBtn').addEventListener('click', closeModal);
    modal.addEventListener('mousedown', e => { if (e.target === modal) closeModal(); });

    field('gst_no').addEventListener('input', () => {
        field('gst_no').value = field('gst_no').value.toUpperCase();
    });

    form.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            closeModal();
            return;
        }

        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
            e.preventDefault();
            form.requestSubmit();
            return;
        }

        if (e.key !== 'Enter' || e.target.tagName === 'TEXTAREA') return;

        const fields = orderedFields();
        const index = fields.indexOf(e.target);
        if (index < 0) return;

        e.preventDefault();
        if (index < fields.length - 1) fields[index + 1].focus();
        else form.requestSubmit();
    });

    const rows = Array.from(document.querySelectorAll('[data-company-row]'));

    rows.forEach((row, index) => row.addEventListener('keydown', e => {
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            rows[Math.min(index + 1, rows.length - 1)]?.focus();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            rows[Math.max(index - 1, 0)]?.focus();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            row.querySelector('.edit-company')?.click();
        }
    }));

    document.addEventListener('keydown', e => {
        if (e.defaultPrevented) return;

        if (e.key === 'Insert' && modal.classList.contains('hidden')) {
            e.preventDefault();
            openCreate(document.activeElement);
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\transportsb\resources\views/masters/companies.blade.php ENDPATH**/ ?>