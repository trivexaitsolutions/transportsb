<?php $__env->startSection('title', $title.' | XYZ Transport'); ?>
<?php $__env->startSection('page-nav-target', '#nav-payments'); ?>

<?php $__env->startPush('styles'); ?>
<style>
.cash-page{min-height:calc(100vh - 56px);background:#f8fafc;padding:16px}
.cash-card{background:#fff;border:1px solid #cbd5e1}
.cash-head{display:flex;align-items:center;justify-content:space-between;gap:16px;border-bottom:1px solid #cbd5e1;padding:12px 14px}
.cash-title{font-size:18px;font-weight:900}.cash-sub{font-size:11px;font-weight:700;color:#64748b}
.cash-filter{display:grid;grid-template-columns:145px 145px repeat(2,minmax(180px,1fr)) auto auto;gap:8px;align-items:end;padding:12px 14px;border-bottom:1px solid #cbd5e1;background:#f8fafc}
.cash-label{display:block;margin-bottom:4px;font-size:10px;font-weight:900;text-transform:uppercase;color:#475569}
.cash-input{height:36px;width:100%;border:1px solid #94a3b8;background:#fff;padding:0 9px;font-weight:800;outline:none}
.cash-input:focus{border-color:#047857;box-shadow:0 0 0 2px #d1fae5}
.cash-btn{height:36px;border:1px solid #94a3b8;background:#fff;padding:0 14px;font-weight:900}.cash-btn.primary{border-color:#08765b;background:#08765b;color:#fff}
.cash-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;padding:12px 14px;border-bottom:1px solid #cbd5e1}
.cash-summary>div{border:1px solid #cbd5e1;background:#f8fafc;padding:10px}.cash-summary small{display:block;font-size:10px;font-weight:900;text-transform:uppercase;color:#64748b}.cash-summary b{display:block;margin-top:2px;font-size:16px}
.cash-table-wrap{overflow:auto}.cash-table{width:100%;min-width:1000px;border-collapse:collapse;font-size:12px}
.cash-table th{background:#dfe7f1;border-right:1px solid #aebccd;border-bottom:1px solid #94a3b8;padding:7px 8px;font-size:10px;font-weight:900;text-transform:uppercase;text-align:left;white-space:nowrap}
.cash-table td{border-right:1px solid #cbd5e1;border-bottom:1px solid #cbd5e1;padding:8px;vertical-align:top}
.cash-table .money{text-align:right;font-weight:900;white-space:nowrap}.cash-table .debit{color:#b91c1c}.cash-table .credit{color:#047857}.cash-table .balance{background:#f8fafc}
.cash-table .total-row td{background:#eef6ff;font-weight:900;border-top:2px solid #64748b}.cash-table .previous-row td{background:#fff7cc;font-weight:900;border-top:1px solid #c59b19}
.cash-table .empty-row td{padding:34px;text-align:center;color:#64748b;font-weight:700}
.cash-note{font-size:10px;color:#64748b}.closing-positive{color:#047857}.closing-negative{color:#b91c1c}
@media(max-width:1000px){.cash-page{padding:8px}.cash-filter{grid-template-columns:1fr 1fr}.cash-filter .wide{grid-column:1/-1}.cash-summary{grid-template-columns:1fr 1fr}}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-workspace cash-page">
    <section class="cash-card">
        <div class="cash-head">
            <div>
                <h1 class="cash-title"><?php echo e($title); ?></h1>
                <p class="cash-sub"><?php echo e($subtitle); ?></p>
            </div>
            <button type="button" class="cash-btn" onclick="window.AppPageExit?.('#nav-payments')">×</button>
        </div>

        <form method="GET" action="<?php echo e($indexRoute); ?>" class="cash-filter">
            <label>
                <span class="cash-label">From Date</span>
                <input type="date" name="from_date" value="<?php echo e($fromDate); ?>" class="cash-input">
            </label>
            <label>
                <span class="cash-label">To Date</span>
                <input type="date" name="to_date" value="<?php echo e($toDate); ?>" class="cash-input">
            </label>

            <?php if($bookType === 'bank'): ?>
                <label class="wide">
                    <span class="cash-label">Company</span>
                    <select name="company_id" class="cash-input" onchange="this.form.submit()">
                        <option value="">All Companies</option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($company->id); ?>" <?php if((int)$selectedCompanyId === (int)$company->id): echo 'selected'; endif; ?>><?php echo e($company->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>

                <label class="wide">
                    <span class="cash-label">Bank</span>
                    <select name="bank_id" class="cash-input">
                        <option value="">All Banks</option>
                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!$selectedCompanyId || (int)$bank->company_id === (int)$selectedCompanyId): ?>
                                <option value="<?php echo e($bank->id); ?>" <?php if((int)$selectedBankId === (int)$bank->id): echo 'selected'; endif; ?>>
                                    <?php echo e($bank->company?->name ? $bank->company->name.' · ' : ''); ?><?php echo e($bank->name); ?>

                                    <?php if($bank->account_number): ?> · <?php echo e($bank->account_number); ?> <?php endif; ?>
                                    <?php if($bank->is_default): ?> · Default <?php endif; ?>
                                </option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
            <?php else: ?>
                <div></div><div></div>
            <?php endif; ?>

            <button class="cash-btn primary" type="submit">Show</button>
            <a href="<?php echo e($indexRoute); ?>" class="cash-btn inline-flex items-center justify-center">Reset</a>
        </form>

        <div class="cash-summary">
            <div>
                <small>Previous Balance</small>
                <b class="<?php echo e($previousBalance >= 0 ? 'closing-positive' : 'closing-negative'); ?>">
                    ₹<?php echo e(number_format(abs($previousBalance),2)); ?><?php echo e($previousBalance < 0 ? ' Cr/Negative' : ''); ?>

                </b>
            </div>
            <div><small>Period Debit</small><b>₹<?php echo e(number_format($debitTotal,2)); ?></b></div>
            <div><small>Period Credit</small><b>₹<?php echo e(number_format($creditTotal,2)); ?></b></div>
            <div>
                <small>Balance as on <?php echo e(\Carbon\Carbon::parse($toDate)->format('d-m-Y')); ?></small>
                <b class="<?php echo e($closingBalance >= 0 ? 'closing-positive' : 'closing-negative'); ?>">
                    ₹<?php echo e(number_format(abs($closingBalance),2)); ?><?php echo e($closingBalance < 0 ? ' Negative' : ''); ?>

                </b>
            </div>
        </div>

        <div class="cash-table-wrap">
            <table class="cash-table">
                <thead>
                    <tr>
                        <th style="width:105px">Date</th>
                        <?php if($bookType === 'bank'): ?>
                            <th style="width:110px">Company</th>
                            <th style="width:150px">Bank</th>
                        <?php endif; ?>
                        <th style="width:170px">Particular</th>
                        <th style="width:180px">Reference</th>
                        <th>Remarks</th>
                        <th style="width:135px;text-align:right">Debit</th>
                        <th style="width:135px;text-align:right">Credit</th>
                        <th style="width:150px;text-align:right">Balance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(\Carbon\Carbon::parse($entry['date'])->format('d-m-Y')); ?></td>
                            <?php if($bookType === 'bank'): ?>
                                <td><b><?php echo e($entry['company']); ?></b></td>
                                <td><?php echo e($entry['bank']); ?></td>
                            <?php endif; ?>
                            <td><b><?php echo e($entry['particular']); ?></b></td>
                            <td><?php echo e($entry['reference'] ?: '-'); ?></td>
                            <td><?php echo e($entry['remarks'] ?: '-'); ?></td>
                            <td class="money debit"><?php echo e($entry['debit'] > 0 ? '₹'.number_format($entry['debit'],2) : '-'); ?></td>
                            <td class="money credit"><?php echo e($entry['credit'] > 0 ? '₹'.number_format($entry['credit'],2) : '-'); ?></td>
                            <td class="money balance">₹<?php echo e(number_format($entry['balance'],2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr class="empty-row">
                            <td colspan="<?php echo e($bookType === 'bank' ? 9 : 7); ?>">No transactions found in this date range.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr class="total-row">
                        <td colspan="<?php echo e($bookType === 'bank' ? 5 : 3); ?>">TOTAL</td>
                        <td class="money debit">₹<?php echo e(number_format($debitTotal,2)); ?></td>
                        <td class="money credit">₹<?php echo e(number_format($creditTotal,2)); ?></td>
                        <td class="money">-</td>
                    </tr>
                    <tr class="previous-row">
                        <td><?php echo e(\Carbon\Carbon::parse($fromDate)->subDay()->format('d-m-Y')); ?></td>
                        <td colspan="<?php echo e($bookType === 'bank' ? 6 : 4); ?>">Previous Balance</td>
                        <td class="money">-</td>
                        <td class="money">₹<?php echo e(number_format($previousBalance,2)); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\transportsb\resources\views/cash/index.blade.php ENDPATH**/ ?>