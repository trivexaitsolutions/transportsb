<?php

namespace App\Http\Controllers;

use App\Models\Company;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class CompanyController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim($request->string('search')->toString());

        $items = Company::query()
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', '%'.$search.'%')
                        ->orWhere('gst_no', 'like', '%'.$search.'%')
                        ->orWhere('address', 'like', '%'.$search.'%');
                });
            })
            ->orderBy('name')
            ->paginate(50)
            ->withQueryString();

        return view('masters.companies', compact('items', 'search'));
    }

    public function store(Request $request): RedirectResponse
    {
        Company::query()->create($this->validated($request));

        return back()->with('success', 'Company added successfully.');
    }

    public function update(Request $request, Company $company): RedirectResponse
    {
        $company->update($this->validated($request, $company->id));

        return back()->with('success', 'Company updated successfully.');
    }

    public function destroy(Company $company): RedirectResponse
    {
        try {
            $company->delete();
        } catch (QueryException) {
            return back()->with('error', 'This company is already used in Bank/Voucher records and cannot be deleted.');
        }

        return back()->with('success', 'Company deleted successfully.');
    }

    private function validated(Request $request, ?int $ignoreId = null): array
    {
        $validated = $request->validate([
            'name' => [
                'required',
                'string',
                'max:150',
                Rule::unique('companies', 'name')->ignore($ignoreId),
            ],
            'gst_no' => ['required', 'string', 'max:30'],
            'address' => ['required', 'string', 'max:2000'],
        ]);

        return [
            'name' => trim((string) $validated['name']),
            'gst_no' => strtoupper(trim((string) $validated['gst_no'])),
            'address' => trim((string) $validated['address']),
        ];
    }
}
