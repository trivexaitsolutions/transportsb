<?php $__env->startSection('title', 'Billing / Acknowledgement | XYZ Transport'); ?>
<?php $__env->startSection('page-nav-target', '#nav-sale'); ?>

<?php $__env->startPush('styles'); ?>
<style>
.app-main{padding:0!important}.billing-workspace{height:calc(100vh - 56px);display:flex;flex-direction:column;background:#fff}.bill-head{padding:10px 16px 8px;border-bottom:1px solid #cbd5e1;background:#f8fafc}.filter-btn{height:36px;min-width:260px;border:1px solid #94a3b8;background:#fff;padding:0 10px;text-align:left;font-weight:800;outline:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.filter-btn:focus{border-color:#047857;box-shadow:0 0 0 2px #d1fae5;background:#ecfdf5}.filter-btn.empty{color:#64748b;font-weight:600}.bill-body{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden}.so-summary{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;padding:9px 16px;border-bottom:1px solid #cbd5e1;background:#fff}.summary-box{border:1px solid #cbd5e1;background:#f8fafc;padding:7px 9px;min-width:0}.summary-box small{display:block;font-size:9px;font-weight:900;text-transform:uppercase;color:#64748b}.summary-box b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:12px}.billing-grid-wrap{flex:1;min-height:220px;overflow:auto;border-bottom:1px solid #cbd5e1}.billing-grid{border-collapse:collapse;min-width:1450px;width:100%;font-size:12px;table-layout:fixed}.billing-grid th{position:sticky;top:0;z-index:3;background:#dfe7f1;border-right:1px solid #aebccd;border-bottom:1px solid #94a3b8;height:33px;padding:4px 6px;text-align:center;font-size:10px;font-weight:900;text-transform:uppercase}.billing-grid td{height:34px;border-right:1px solid #cbd5e1;border-bottom:1px solid #cbd5e1;padding:5px 7px;background:#fff;font-weight:700}.billing-grid tr.pending td{background:#fffbea}.billing-grid tr.billed td{background:#ecfdf5;color:#475569}.billing-grid tr.billed td.status-cell{color:#047857}.trip-check{width:18px;height:18px;accent-color:#047857;outline:none}.trip-check:focus{box-shadow:0 0 0 3px #a7f3d0}.status-badge{font-size:10px;font-weight:900}.invoice-section{height:250px;overflow:auto;background:#f8fafc;border-top:1px solid #cbd5e1}.invoice-head{position:sticky;top:0;z-index:2;display:flex;align-items:center;padding:7px 16px;background:#eef2f7;border-bottom:1px solid #cbd5e1}.invoice-table{width:100%;border-collapse:collapse;font-size:11px}.invoice-table th,.invoice-table td{border:1px solid #cbd5e1;padding:6px 7px;text-align:left}.invoice-table th{background:#dfe7f1;font-size:9px;text-transform:uppercase}.amount{text-align:right!important;white-space:nowrap}.action-link{border:0;background:transparent;color:#1d4ed8;text-decoration:underline;font-weight:900;cursor:pointer;padding:2px 4px}.action-link:focus{outline:2px solid #2563eb;outline-offset:1px}.bill-foot{height:54px;display:flex;align-items:center;padding:7px 16px;background:#f8fafc;gap:10px}.bill-foot .status{font-size:11px;font-weight:900;color:#64748b}.bill-foot .status.ok{color:#047857}.bill-foot .status.error{color:#b91c1c}.foot-actions{margin-left:auto;display:flex;gap:8px}.vbtn{height:36px;border:1px solid #94a3b8;background:#fff;padding:0 14px;font-weight:900}.vbtn:focus{outline:2px solid #047857;outline-offset:1px}.vbtn-primary{background:#08765b;color:#fff;border-color:#08765b}.modal-backdrop{position:fixed;inset:0;z-index:250;background:rgba(15,23,42,.58);display:flex;align-items:center;justify-content:center;padding:16px}.modal-backdrop.hidden{display:none!important}.modal-card{width:min(900px,97vw);max-height:94vh;overflow:auto;background:#fff;border:1px solid #64748b;box-shadow:0 24px 70px rgba(15,23,42,.35)}.modal-head{display:flex;align-items:center;justify-content:space-between;background:#055b46;color:#fff;padding:11px 16px}.modal-input{height:38px;border:1px solid #94a3b8;padding:0 8px;outline:none;width:100%;background:#fff}.modal-input:focus{border-color:#047857;box-shadow:0 0 0 2px #d1fae5}.modal-textarea{min-height:72px;padding:8px}.pay-summary{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.pay-summary>div{border:1px solid #cbd5e1;background:#f8fafc;padding:9px}.pay-summary small{display:block;font-size:9px;font-weight:900;color:#64748b;text-transform:uppercase}.pay-summary b{font-size:14px}.modal-table{width:100%;border-collapse:collapse;font-size:11px}.modal-table th,.modal-table td{border:1px solid #cbd5e1;padding:6px}.modal-table th{background:#e9eef5;font-size:9px;text-transform:uppercase}.row-delete{border:0;background:transparent;color:#b91c1c;font-weight:900}.print-card{width:min(1120px,98vw);height:min(92vh,920px);display:flex;flex-direction:column;background:#fff;border:1px solid #64748b}.print-frame{flex:1;width:100%;border:0;background:#d1d5db}.attachment-list a{display:inline-block;margin:2px 4px 2px 0;color:#1d4ed8;text-decoration:underline;font-weight:800}.empty-area{padding:28px;text-align:center;color:#64748b;font-weight:700}.kbd{border:1px solid #cbd5e1;background:#fff;padding:0 4px;font-size:9px;font-weight:900}
@media(max-width:1100px){.so-summary{grid-template-columns:repeat(3,minmax(0,1fr))}.filter-btn{min-width:210px}}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-workspace billing-workspace" id="billingWorkspace">
    <div class="bill-head">
        <div class="flex flex-wrap items-end gap-3">
            <div class="mr-3"><h1 class="text-lg font-black">Billing / Acknowledgement</h1><p class="text-xs font-semibold text-slate-500">Select acknowledged trucks from one SO and generate one common customer bill.</p></div>
            <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Customer</span><button type="button" id="customerBtn" class="filter-btn <?php echo e($selectedCustomer ? '' : 'empty'); ?>" data-customer-id="<?php echo e($selectedCustomer?->id); ?>"><?php echo e($selectedCustomer?->name ?: 'Select Customer'); ?></button></label>
            <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Pending SO</span><button type="button" id="soBtn" class="filter-btn <?php echo e($selectedOrder ? '' : 'empty'); ?>" data-so-id="<?php echo e($selectedOrder?->id); ?>" <?php echo e($selectedCustomer ? '' : 'disabled'); ?>><?php echo e($selectedOrder?->so_number ?: 'Select SO'); ?></button></label>
            <div class="ml-auto text-right"><div id="headerStatus" class="text-[11px] font-black text-emerald-700">Ready</div><button type="button" id="closeBilling" class="mt-1 h-8 w-8 border border-slate-300 bg-white font-black">×</button></div>
        </div>
        <div class="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-[10px] font-bold text-slate-600">
            <span><b>Enter Customer / SO</b> Open searchable selector</span><span><b>Enter on truck</b> Select + next truck</span><span><b>↑ ↓</b> Move truck rows</span><span><b>Alt+A</b> Check all pending</span><span><b>Ctrl+B</b> Create Bill</span><span><b>Esc</b> Close modal / focus Sale navbar</span>
        </div>
    </div>

    <div class="bill-body">
        <div class="so-summary hidden" id="soSummary">
            <div class="summary-box"><small>SO No.</small><b id="sumSo">-</b></div><div class="summary-box"><small>Route</small><b id="sumRoute">-</b></div><div class="summary-box"><small>Description / Service</small><b id="sumDescription">-</b></div><div class="summary-box"><small>Per Trip Cost</small><b id="sumRate">₹0.00</b></div><div class="summary-box"><small>Trips</small><b id="sumTrips">0</b></div><div class="summary-box"><small>Pending Billing</small><b id="sumPending">0</b></div>
        </div>
        <div class="billing-grid-wrap" id="tripWrap">
            <table class="billing-grid">
                <colgroup><col style="width:55px"><col style="width:95px"><col style="width:85px"><col style="width:110px"><col style="width:110px"><col style="width:135px"><col style="width:150px"><col style="width:120px"><col style="width:160px"><col style="width:170px"><col style="width:260px"></colgroup>
                <thead><tr><th>Select</th><th>Status</th><th>Sr No</th><th>LR No</th><th>LR Date</th><th>Lorry No</th><th>Vehicle Type</th><th>Transport</th><th>Supplier</th><th>Bill No</th><th>Description</th></tr></thead>
                <tbody id="tripBody"><tr><td colspan="11" class="empty-area">Select Customer and pending SO.</td></tr></tbody>
            </table>
        </div>

        <div class="invoice-section" id="invoiceSection">
            <div class="invoice-head"><div><b>Customer Bill History</b><span class="ml-2 text-[10px] font-semibold text-slate-500">Payments are invoice-wise, not truck-wise.</span></div><div class="ml-auto text-[10px] font-bold text-slate-500">Enter / Click Add Payment to record receipt</div></div>
            <table class="invoice-table"><thead><tr><th>Bill No</th><th>Date</th><th>SO No</th><th>Trips</th><th class="amount">Total</th><th class="amount">Paid</th><th class="amount">Outstanding</th><th>Attachments</th><th>Add Payment</th><th>Print</th></tr></thead><tbody id="invoiceBody"><tr><td colspan="10" class="empty-area">Select a customer to see bills.</td></tr></tbody></table>
        </div>
    </div>

    <div class="bill-foot">
        <button type="button" id="checkAllBtn" class="vbtn">Check All <span class="kbd">Alt+A</span></button>
        <div id="footerStatus" class="status">No trucks selected</div>
        <div class="foot-actions"><button type="button" id="createBillBtn" class="vbtn vbtn-primary">Create Bill <span class="kbd">Ctrl+B</span></button></div>
    </div>
</div>

<div class="modal-backdrop hidden" id="billModal" role="dialog" aria-modal="true">
    <div class="modal-card">
        <div class="modal-head"><h2 class="font-black">Create Invoice from Acknowledged Trucks</h2><button type="button" id="billClose" class="text-2xl">×</button></div>
        <form id="billForm" class="p-4" enctype="multipart/form-data">
            <div class="pay-summary"><div><small>Selected Trucks</small><b id="draftTrips">0</b></div><div><small>Total Amount</small><b id="draftTotal">₹0.00</b></div><div><small>Paid Amount</small><b id="draftPaid">₹0.00</b></div><div><small>Outstanding</small><b id="draftOutstanding">₹0.00</b></div></div>
            <div class="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
                <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Invoice Date</span><input id="invoiceDate" name="invoice_date" type="date" class="modal-input"></label>
                <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Total Amount <span class="text-red-700">*</span></span><input id="billTotalAmount" name="total_amount" type="number" step="0.01" min="0.01" class="modal-input" autocomplete="off"></label>
                <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Paid Amount</span><input id="billPaidAmount" name="paid_amount" type="number" step="0.01" min="0" class="modal-input" autocomplete="off"></label>
                <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Acknowledgement Attachments <span class="text-red-700">*</span></span><input id="billAttachments" name="attachments[]" type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.webp" class="modal-input py-1"><span class="mt-1 block text-[10px] font-semibold text-slate-500">Multiple PDF / image files allowed. At least one acknowledgement attachment is required.</span></label>
                <label class="md:col-span-2"><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Remarks</span><textarea id="billRemarks" name="remarks" class="modal-input modal-textarea"></textarea></label>
            </div>
            <div id="billError" class="mt-3 hidden text-sm font-black text-red-700"></div>
            <div class="mt-4 flex justify-end gap-2"><button type="button" id="billCancel" class="vbtn">Cancel</button><button type="submit" id="billSubmit" class="vbtn vbtn-primary">Create Bill & Print <span class="kbd">Ctrl+S</span></button></div>
            <div class="mt-2 text-right text-[10px] font-semibold text-slate-500">Enter: Date → Total Amount → Paid Amount → Attachments → Remarks → Create · Esc Close</div>
        </form>
    </div>
</div>

<div class="modal-backdrop hidden" id="paymentModal" role="dialog" aria-modal="true">
    <div class="modal-card">
        <div class="modal-head"><h2 class="font-black">Add Payment</h2><button type="button" id="paymentClose" class="text-2xl">×</button></div>
        <div class="p-4">
            <div class="grid grid-cols-1 gap-3 md:grid-cols-2">
                <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Total Amount</span><input id="payTotal" class="modal-input bg-slate-100 font-black" readonly></label>
                <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Total Paid</span><input id="payPaid" class="modal-input bg-slate-100 font-black" readonly></label>
                <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Amount</span><input id="payAmount" type="number" min="0.01" step="0.01" class="modal-input" autocomplete="off"></label>
                <label><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Payment Method</span><select id="payMode" class="modal-input"><option>Cash</option><option>NEFT</option><option>RTGS</option><option>UPI</option><option>Cheque</option><option>Other</option></select></label>
                <label class="md:col-span-2"><span class="mb-1 block text-[10px] font-black uppercase text-slate-500">Remark</span><input id="payRemarks" class="modal-input" autocomplete="off"></label>
            </div>
            <div class="mt-4 flex justify-end"><button id="payAdd" form="paymentForm" class="h-[38px] bg-emerald-800 px-4 font-black text-white">Add Payment</button></div>
            <form id="paymentForm" class="hidden"></form>
            <div class="mt-2 text-right text-xs font-semibold text-slate-500">Enter: Amount → Payment Method → Remark → Add Payment · Esc Close</div>
        </div>
    </div>
</div>

<div class="modal-backdrop hidden" id="printModal" role="dialog" aria-modal="true">
    <div class="print-card">
        <div class="modal-head"><h2 class="font-black">Tax Invoice Preview</h2><div class="flex gap-2"><button type="button" id="printNow" class="border border-white/40 px-3 py-1 font-black">Print</button><button type="button" id="printClose" class="text-2xl">×</button></div></div>
        <iframe id="printFrame" class="print-frame" title="Tax Invoice"></iframe>
        <div class="px-4 py-2 text-right text-[10px] font-semibold text-slate-500">Esc closes preview and returns to Billing page.</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded',()=>{
    const csrf=document.querySelector('meta[name="csrf-token"]').content;
    const routes={data:<?php echo json_encode(route('sale.billing.data'), 15, 512) ?>,soOptions:<?php echo json_encode(route('sale.billing.so-options'), 15, 512) ?>,store:<?php echo json_encode(route('sale.billing.store'), 15, 512) ?>,base:<?php echo json_encode(url('/sale/bills'), 15, 512) ?>};
    const customerBtn=document.getElementById('customerBtn'),soBtn=document.getElementById('soBtn'),tripBody=document.getElementById('tripBody'),invoiceBody=document.getElementById('invoiceBody');
    const footerStatus=document.getElementById('footerStatus'),headerStatus=document.getElementById('headerStatus'),checkAllBtn=document.getElementById('checkAllBtn'),createBillBtn=document.getElementById('createBillBtn');
    let state={customerId:Number(customerBtn.dataset.customerId)||null,customerName:customerBtn.textContent.trim(),soId:Number(soBtn.dataset.soId)||null,order:null,trips:[],invoices:[],selected:new Set(),tripOpener:null,paymentInvoiceId:null,paymentOpener:null,printOpener:null};
    const money=n=>'₹'+Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
    const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
    const today=()=>{const d=new Date(),o=d.getTimezoneOffset();return new Date(d.getTime()-o*60000).toISOString().slice(0,10)};
    const setStatus=(msg,type='')=>{footerStatus.textContent=msg;footerStatus.className='status '+type;headerStatus.textContent=msg;headerStatus.className='text-[11px] font-black '+(type==='error'?'text-red-700':'text-emerald-700')};
    const updateUrl=()=>{const u=new URL(window.location.href);state.customerId?u.searchParams.set('customer_id',state.customerId):u.searchParams.delete('customer_id');state.soId?u.searchParams.set('sales_order_id',state.soId):u.searchParams.delete('sales_order_id');history.replaceState({},'',u.pathname+u.search)};

    function openCustomer(search=''){
        window.MasterSelector.open({type:'customers',title:'Select Customer',search,opener:customerBtn,onSelect:item=>{state.customerId=Number(item.id);state.customerName=item.name;state.soId=null;state.order=null;state.selected.clear();customerBtn.dataset.customerId=item.id;customerBtn.textContent=item.name;customerBtn.classList.remove('empty');soBtn.dataset.soId='';soBtn.textContent='Select SO';soBtn.classList.add('empty');soBtn.disabled=false;updateUrl();loadData(false).then(()=>setTimeout(()=>soBtn.focus(),20));}});
    }
    function openSO(search=''){
        if(!state.customerId){setStatus('Select Customer first.','error');customerBtn.focus();return;}
        const url=routes.soOptions+'?customer_id='+encodeURIComponent(state.customerId);
        window.MasterSelector.open({url,title:'Select Pending SO',search,opener:soBtn,onSelect:item=>{state.soId=Number(item.id);state.selected.clear();soBtn.dataset.soId=item.id;soBtn.textContent=item.so_number||item.name;soBtn.classList.remove('empty');updateUrl();loadData(true);}});
    }
    customerBtn.addEventListener('click',()=>openCustomer());soBtn.addEventListener('click',()=>openSO());
    [customerBtn,soBtn].forEach(btn=>btn.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();btn===customerBtn?openCustomer():openSO();}else if(e.key==='Backspace'){e.preventDefault();if(btn===customerBtn){state.customerId=null;state.customerName='';state.soId=null;customerBtn.textContent='Select Customer';customerBtn.classList.add('empty');soBtn.textContent='Select SO';soBtn.classList.add('empty');soBtn.disabled=true;}else{state.soId=null;soBtn.textContent='Select SO';soBtn.classList.add('empty');}state.selected.clear();updateUrl();loadData(false);}}));

    async function loadData(focusTrips=false){
        const u=new URL(routes.data,window.location.origin);if(state.customerId)u.searchParams.set('customer_id',state.customerId);if(state.soId)u.searchParams.set('sales_order_id',state.soId);
        try{setStatus('Loading...');const r=await fetch(u,{headers:{Accept:'application/json'}}),d=await r.json();if(!r.ok)throw new Error(d.message||'Unable to load billing data');state.order=d.order;state.trips=d.trips||[];state.invoices=d.invoices||[];state.selected=new Set([...state.selected].filter(id=>state.trips.some(t=>t.id===id&&!t.billed)));renderAll();setStatus(state.order?`${state.order.pending_count} truck(s) pending billing`:'Ready','ok');if(focusTrips)setTimeout(()=>focusFirstPending(),20);}catch(err){setStatus(err.message||'Unable to load','error');}
    }
    function renderAll(){renderSummary();renderTrips();renderInvoices();updateSelectionStatus();}
    function renderSummary(){const box=document.getElementById('soSummary');if(!state.order){box.classList.add('hidden');return;}box.classList.remove('hidden');document.getElementById('sumSo').textContent=state.order.so_number;document.getElementById('sumRoute').textContent=`${state.order.from_location} → ${state.order.to_location}`;document.getElementById('sumDescription').textContent=state.order.description||'-';document.getElementById('sumRate').textContent=money(state.order.per_trip_cost);document.getElementById('sumTrips').textContent=`${state.order.billed_count} billed / ${state.order.voucher_count} sent / ${state.order.trips_quantity} ordered`;document.getElementById('sumPending').textContent=state.order.pending_count;}
    function renderTrips(){if(!state.order){tripBody.innerHTML='<tr><td colspan="11" class="empty-area">Select Customer and pending SO.</td></tr>';return;}if(!state.trips.length){tripBody.innerHTML='<tr><td colspan="11" class="empty-area">No voucher/truck entries found for this SO.</td></tr>';return;}tripBody.innerHTML=state.trips.map((t,i)=>`<tr class="${t.billed?'billed':'pending'}" data-trip-row="${i}"><td class="text-center">${t.billed?'<span class="status-badge">✓</span>':`<input type="checkbox" class="trip-check" data-trip-check="${t.id}" data-trip-index="${i}" ${state.selected.has(t.id)?'checked':''}>`}</td><td class="status-cell"><span class="status-badge">${t.billed?'BILLED':'PENDING'}</span></td><td>${esc(t.sr_no)}</td><td>${esc(t.lr_no||'-')}</td><td>${esc(t.lr_date||'-')}</td><td>${esc(t.lorry_number||'-')}</td><td>${esc(t.vehicle_type||'-')}</td><td>${esc(t.transport_name||'-')}</td><td>${esc(t.supplier||'-')}</td><td>${t.billed?`<button type="button" class="action-link" data-print-invoice="${t.invoice_id}">${esc(t.bill_no)}</button>`:'-'}</td><td>${esc(t.description||'-')}</td></tr>`).join('');}
    function renderInvoices(){if(!state.customerId){invoiceBody.innerHTML='<tr><td colspan="10" class="empty-area">Select a customer to see bills.</td></tr>';return;}if(!state.invoices.length){invoiceBody.innerHTML='<tr><td colspan="10" class="empty-area">No bills generated for this selection.</td></tr>';return;}invoiceBody.innerHTML=state.invoices.map(i=>`<tr><td><b>${esc(i.bill_no)}</b></td><td>${esc(i.invoice_date)}</td><td>${esc(i.so_number||'-')}</td><td>${i.trip_count}</td><td class="amount"><b>${money(i.total_amount)}</b></td><td class="amount">${money(i.paid_amount)}</td><td class="amount" style="color:${i.outstanding>0?'#b91c1c':'#047857'}"><b>${money(i.outstanding)}</b></td><td class="attachment-list">${i.attachments?.length?i.attachments.map(a=>`<a href="${a.url}" target="_blank" rel="noopener">${esc(a.name)}</a>`).join(''):'-'}</td><td><button type="button" class="action-link" data-payment-invoice="${i.id}">Add Payment</button></td><td><button type="button" class="action-link" data-print-invoice="${i.id}">Print</button></td></tr>`).join('');}
    function pendingChecks(){return Array.from(document.querySelectorAll('[data-trip-check]'));}
    function focusFirstPending(){pendingChecks()[0]?.focus();}
    function focusCheckByPosition(current,delta){const arr=pendingChecks();const i=arr.indexOf(current);arr[Math.max(0,Math.min(arr.length-1,i+delta))]?.focus();}
    tripBody.addEventListener('change',e=>{const c=e.target.closest('[data-trip-check]');if(!c)return;const id=Number(c.dataset.tripCheck);c.checked?state.selected.add(id):state.selected.delete(id);updateSelectionStatus();});
    tripBody.addEventListener('keydown',e=>{const c=e.target.closest('[data-trip-check]');if(!c)return;if(e.key==='Enter'){e.preventDefault();c.checked=!c.checked;c.dispatchEvent(new Event('change',{bubbles:true}));focusCheckByPosition(c,1);}else if(e.key==='ArrowDown'){e.preventDefault();focusCheckByPosition(c,1);}else if(e.key==='ArrowUp'){e.preventDefault();focusCheckByPosition(c,-1);}});
    tripBody.addEventListener('click',e=>{const p=e.target.closest('[data-print-invoice]');if(p)openPrint(Number(p.dataset.printInvoice),p,true);});
    function updateSelectionStatus(){const c=state.selected.size;const freight=state.order?c*Number(state.order.per_trip_cost||0):0;footerStatus.textContent=c?`${c} truck(s) selected · Freight ${money(freight)}`:'No trucks selected';}
    function toggleAll(){if(!state.order)return;const pending=state.trips.filter(t=>!t.billed).map(t=>t.id);const all=pending.length&&pending.every(id=>state.selected.has(id));state.selected=new Set(all?[]:pending);renderTrips();updateSelectionStatus();if(!all)focusFirstPending();}
    checkAllBtn.addEventListener('click',toggleAll);

    const billModal=document.getElementById('billModal'),billForm=document.getElementById('billForm'),invoiceDate=document.getElementById('invoiceDate'),totalInput=document.getElementById('billTotalAmount'),initialPaidInput=document.getElementById('billPaidAmount'),attachInput=document.getElementById('billAttachments'),remarksInput=document.getElementById('billRemarks'),billError=document.getElementById('billError'),billSubmit=document.getElementById('billSubmit');
    function updateDraft(){const total=Number(totalInput.value||0),paid=Number(initialPaidInput.value||0);document.getElementById('draftTrips').textContent=state.selected.size;document.getElementById('draftTotal').textContent=money(total);document.getElementById('draftPaid').textContent=money(paid);document.getElementById('draftOutstanding').textContent=money(Math.max(0,total-paid));}
    function openBill(){if(!state.customerId||!state.soId){setStatus('Select Customer and SO first.','error');window.AppToast?.('Select Customer and SO first.','error');return;}if(!state.selected.size){setStatus('Select at least one acknowledged truck.','error');window.AppToast?.('Select at least one acknowledged truck.','error');focusFirstPending();return;}state.tripOpener=document.activeElement;invoiceDate.value=today();totalInput.value='';initialPaidInput.value='';attachInput.value='';remarksInput.value='';billError.classList.add('hidden');billError.textContent='';updateDraft();billModal.classList.remove('hidden');setTimeout(()=>invoiceDate.focus(),20);}
    function closeBill(){billModal.classList.add('hidden');setTimeout(()=>state.tripOpener?.focus?.()||createBillBtn.focus(),0);}
    createBillBtn.addEventListener('click',openBill);document.getElementById('billClose').addEventListener('click',closeBill);document.getElementById('billCancel').addEventListener('click',closeBill);billModal.addEventListener('mousedown',e=>{if(e.target===billModal)closeBill();});totalInput.addEventListener('input',updateDraft);initialPaidInput.addEventListener('input',updateDraft);
    billForm.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closeBill();return;}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();billForm.requestSubmit();return;}if(e.key!=='Enter'||e.target===remarksInput)return;e.preventDefault();const order=[invoiceDate,totalInput,initialPaidInput,attachInput,remarksInput,billSubmit],i=order.indexOf(e.target);if(e.target===invoiceDate&&!invoiceDate.value){invoiceDate.showPicker?.();return;}if(i>=0&&i<order.length-1){order[i+1].focus();order[i+1].select?.();}else if(e.target===billSubmit)billForm.requestSubmit();});
    billForm.addEventListener('submit',async e=>{e.preventDefault();billError.classList.add('hidden');const total=Number(totalInput.value||0),paid=Number(initialPaidInput.value||0);if(total<=0){window.AppToast?.('Enter Total Amount.','error');totalInput.focus();return;}if(paid<0||paid>total){window.AppToast?.('Paid Amount must be between 0 and Total Amount.','error');initialPaidInput.focus();return;}if(!attachInput.files.length){window.AppToast?.('Please add at least one acknowledgement attachment.','error');attachInput.focus();return;}billSubmit.disabled=true;billSubmit.textContent='Creating...';const fd=new FormData();fd.append('customer_id',state.customerId);fd.append('sales_order_id',state.soId);[...state.selected].forEach(id=>fd.append('voucher_ids[]',id));fd.append('invoice_date',invoiceDate.value);fd.append('total_amount',totalInput.value);fd.append('paid_amount',initialPaidInput.value||'0');fd.append('remarks',remarksInput.value||'');Array.from(attachInput.files).forEach(f=>fd.append('attachments[]',f));try{const r=await fetch(routes.store,{method:'POST',headers:{Accept:'application/json','X-CSRF-TOKEN':csrf},body:fd}),d=await r.json();if(!r.ok)throw new Error(d.message||Object.values(d.errors||{})[0]?.[0]||'Unable to create bill');billModal.classList.add('hidden');state.selected.clear();await loadData(false);if(state.order&&Number(state.order.pending_count)===0){state.soId=null;state.order=null;soBtn.dataset.soId='';soBtn.textContent='Select SO';soBtn.classList.add('empty');updateUrl();await loadData(false);}setStatus(d.message,'ok');window.AppToast?.(d.message||'Bill created successfully.','success');openPrint(d.invoice.id,createBillBtn,true);}catch(err){window.AppToast?.(err.message||'Unable to create bill.','error',5500);}finally{billSubmit.disabled=false;billSubmit.innerHTML='Create Bill & Print <span class="kbd">Ctrl+S</span>';}});

    const paymentModal=document.getElementById('paymentModal'),payAmount=document.getElementById('payAmount'),payMode=document.getElementById('payMode'),payRemarks=document.getElementById('payRemarks'),payAdd=document.getElementById('payAdd');
    async function openPayment(id,opener){state.paymentInvoiceId=id;state.paymentOpener=opener;paymentModal.classList.remove('hidden');payAmount.value='';payRemarks.value='';await refreshPayments();setTimeout(()=>payAmount.focus(),20);}
    function closePayment(){paymentModal.classList.add('hidden');state.paymentInvoiceId=null;setTimeout(()=>state.paymentOpener?.focus?.(),0);}
    async function refreshPayments(){if(!state.paymentInvoiceId)return;try{const r=await fetch(`${routes.base}/${state.paymentInvoiceId}/payments`,{headers:{Accept:'application/json'}}),d=await r.json();if(!r.ok)throw new Error(d.message||'Unable to load payment details');document.getElementById('payTotal').value=money(d.invoice.total_amount);document.getElementById('payPaid').value=money(d.invoice.paid_amount);}catch(err){window.AppToast?.(err.message||'Unable to load payment details.','error');}}
    document.getElementById('paymentClose').addEventListener('click',closePayment);paymentModal.addEventListener('mousedown',e=>{if(e.target===paymentModal)closePayment();});
    paymentModal.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closePayment();return;}if(e.key!=='Enter')return;e.preventDefault();const order=[payAmount,payMode,payRemarks,payAdd],i=order.indexOf(e.target);if(i>=0&&i<order.length-1){order[i+1].focus();order[i+1].select?.();}else if(e.target===payAdd)submitPayment();});
    async function submitPayment(){if(!state.paymentInvoiceId)return;const amount=Number(payAmount.value||0);if(amount<=0){window.AppToast?.('Enter payment amount.','error');payAmount.focus();return;}payAdd.disabled=true;try{const r=await fetch(`${routes.base}/${state.paymentInvoiceId}/payments`,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-TOKEN':csrf},body:JSON.stringify({amount,payment_mode:payMode.value,remarks:payRemarks.value})}),d=await r.json();if(!r.ok)throw new Error(d.message||Object.values(d.errors||{})[0]?.[0]||'Payment failed');window.AppToast?.(d.message||'Payment saved.','success');payAmount.value='';payRemarks.value='';await refreshPayments();await loadData(false);payAmount.focus();}catch(err){window.AppToast?.(err.message||'Payment failed.','error',5500);payAmount.focus();}finally{payAdd.disabled=false;}}
    payAdd.addEventListener('click',e=>{e.preventDefault();submitPayment();});

    invoiceBody.addEventListener('click',e=>{const p=e.target.closest('[data-payment-invoice]');if(p)openPayment(Number(p.dataset.paymentInvoice),p);const pr=e.target.closest('[data-print-invoice]');if(pr)openPrint(Number(pr.dataset.printInvoice),pr,true);});
    invoiceBody.addEventListener('keydown',e=>{const p=e.target.closest('[data-payment-invoice]');if(p&&e.key==='Enter'){e.preventDefault();openPayment(Number(p.dataset.paymentInvoice),p);}const pr=e.target.closest('[data-print-invoice]');if(pr&&e.key==='Enter'){e.preventDefault();openPrint(Number(pr.dataset.printInvoice),pr,true);}});

    const printModal=document.getElementById('printModal'),printFrame=document.getElementById('printFrame');let autoPrint=false;
    function openPrint(id,opener,auto=false){state.printOpener=opener;autoPrint=auto;printFrame.src=`${routes.base}/${id}/print?embedded=1`;printModal.classList.remove('hidden');}
    function closePrint(){printModal.classList.add('hidden');printFrame.src='about:blank';autoPrint=false;setTimeout(()=>state.printOpener?.focus?.(),0);}
    printFrame.addEventListener('load',()=>{if(autoPrint&&printFrame.src!=='about:blank'){setTimeout(()=>{try{printFrame.contentWindow.focus();printFrame.contentWindow.print();}catch(e){}},250);autoPrint=false;}});
    document.getElementById('printNow').addEventListener('click',()=>{try{printFrame.contentWindow.focus();printFrame.contentWindow.print();}catch(e){}});document.getElementById('printClose').addEventListener('click',closePrint);printModal.addEventListener('mousedown',e=>{if(e.target===printModal)closePrint();});
    window.addEventListener('message',e=>{if(e.origin===window.location.origin&&e.data?.type==='xyz-invoice-afterprint'&&!printModal.classList.contains('hidden'))closePrint();});

    document.getElementById('closeBilling').addEventListener('click',()=>window.AppPageExit?.('#nav-sale'));
    window.addEventListener('keydown',e=>{
        if(!printModal.classList.contains('hidden')){if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();closePrint();}return;}
        if(!paymentModal.classList.contains('hidden')){if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();closePayment();}return;}
        if(!billModal.classList.contains('hidden')){if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();closeBill();}return;}
        if(e.altKey&&e.key.toLowerCase()==='a'){e.preventDefault();toggleAll();return;}
        if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='b'){e.preventDefault();openBill();return;}
    });

    loadData(false).then(()=>{if(!state.customerId)setTimeout(()=>customerBtn.focus(),30);else if(!state.soId)setTimeout(()=>soBtn.focus(),30);else setTimeout(()=>focusFirstPending(),30);});
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\transportsb\resources\views/sale/billing/index.blade.php ENDPATH**/ ?>