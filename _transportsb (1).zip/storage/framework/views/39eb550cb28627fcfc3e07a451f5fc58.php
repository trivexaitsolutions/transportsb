<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Tax Invoice - <?php echo e($invoice->bill_no); ?></title>
<style>
*{box-sizing:border-box}body{font-family:Arial,Helvetica,sans-serif;margin:0;background:#d1d5db;color:#111;font-size:12px}.paper{width:210mm;min-height:297mm;margin:0 auto;background:#fff;padding:9mm 10mm}.center{text-align:center}.right{text-align:right}.bold{font-weight:800}.company-name{font-size:27px;font-weight:900;letter-spacing:.2px}.tagline{font-size:11px;font-weight:800;text-transform:uppercase;margin-top:2px}.company-meta{font-size:10px;font-weight:700;margin-top:4px}.rule{border-top:2px solid #111;margin:7px 0}.invoice-title{font-size:21px;font-weight:900;text-decoration:underline;margin:9px 0 8px}.uploaded-letterhead{text-align:center;margin-bottom:3mm}.uploaded-letterhead img{display:block;width:100%;max-height:50mm;object-fit:contain}.top-grid{display:grid;grid-template-columns:1fr 1fr;border:1px solid #111}.top-grid>div{padding:8px 9px;border-right:1px solid #111}.top-grid>div:last-child{border-right:0}.meta-line{display:flex;gap:8px;margin:5px 0;font-size:14px;line-height:1.25}.meta-line .label{font-weight:900;min-width:135px}.to-box{border:1px solid #111;border-top:0;padding:9px;min-height:92px;font-size:13px}.to-box h3{margin:0 0 5px;font-size:12px}.to-name{font-size:16px;font-weight:900}.service-box{border:1px solid #111;border-top:0;padding:7px 8px;font-weight:700;line-height:1.45}.grid{width:100%;border-collapse:collapse}.grid th,.grid td{border:1px solid #111;padding:6px 5px;vertical-align:middle}.grid th{font-size:9px;text-transform:uppercase}.grid .num{text-align:right}.totals{width:100%;border-collapse:collapse}.totals td{border:1px solid #111;padding:6px}.totals td:first-child{text-align:right;font-weight:800}.amount-words{border:1px solid #111;border-top:0;padding:8px;font-weight:800}.customer-bill-note{border:1px solid #111;border-top:0;padding:8px;font-weight:900;text-transform:uppercase}.gst-summary{margin-top:8px;width:100%;border-collapse:collapse}.gst-summary th,.gst-summary td{border:1px solid #111;padding:5px}.gst-summary th{font-size:9px}.terms-sign{display:grid;grid-template-columns:1.35fr .65fr;border:1px solid #111;border-top:0;min-height:145px}.terms{padding:8px;border-right:1px solid #111}.terms h4{margin:0 0 5px;text-decoration:underline}.terms ol{margin:4px 0 0;padding-left:18px;line-height:1.45}.signature{padding:8px;display:flex;flex-direction:column;justify-content:space-between;text-align:center}.bank{margin-top:8px;border:1px solid #111;padding:8px;line-height:1.45}.footer-note{margin-top:5px;font-size:9px;color:#374151}@media print{body{background:#fff}.paper{width:auto;min-height:auto;margin:0;padding:7mm}@page{size:A4;margin:0}}
</style>
</head>
<body>
<?php
    $customer = $invoice->customer;
    $order = $invoice->salesOrder;
    $topMargin = max(0, (float) ($printSettings->letterhead_top_margin_mm ?? 0));
    $gstNo = strtoupper(trim((string) ($customer?->gst_no ?? '')));
    $pan = strlen($gstNo) >= 12 ? substr($gstNo, 2, 10) : '-';
    $stateCode = strlen($gstNo) >= 2 ? substr($gstNo, 0, 2) : '27';
    if ($stateCode === '27') $stateCode = '27 (Maharashtra)';
    $paid = (float) ($invoice->paid_amount ?? 0);
    $balance = max(0, round((float)$invoice->total_amount - $paid, 2));
    $amountWords = number_format((float)$invoice->total_amount, 2).' Rupees Only';
    if (class_exists('NumberFormatter')) {
        try {
            $fmt = new NumberFormatter('en_IN', NumberFormatter::SPELLOUT);
            $whole = (int) floor((float)$invoice->total_amount);
            $paise = (int) round((((float)$invoice->total_amount) - $whole) * 100);
            $amountWords = ucwords($fmt->format($whole)).' Rupees'.($paise ? ' and '.ucwords($fmt->format($paise)).' Paise' : '').' Only';
        } catch (Throwable $e) {}
    }
    $profile = [
        'name'=>'XYZ TRANSPORT','tagline'=>'Fleet Owners & Transport Contractor','address'=>'Maharashtra, India',
        'phone'=>'9876543210','email'=>'accounts@xyztransport.com','pan'=>'ABCDE1234F','gst_no'=>'27ABCDE1234F1Z5',
        'bank_holder'=>'XYZ TRANSPORT','bank_name'=>'Bank of Baroda','bank_address'=>'Maharashtra Branch',
        'account_no'=>'000000000000','ifsc'=>'BARB0000000',
    ];
?>
<div class="paper">
    <?php if(!empty($printSettings->letterhead_image)): ?>
        <div class="uploaded-letterhead"><img src="<?php echo e(asset($printSettings->letterhead_image)); ?>" alt="Letterhead"></div>
    <?php endif; ?>
    <?php if($topMargin > 0): ?><div style="height:<?php echo e($topMargin); ?>mm"></div><?php endif; ?>

    <?php if($topMargin <= 0): ?>
        <div class="center"><div class="company-name"><?php echo e($profile['name']); ?></div><div class="tagline"><?php echo e($profile['tagline']); ?></div><div class="company-meta"><?php echo e($profile['address']); ?> &nbsp;|&nbsp; Mob: <?php echo e($profile['phone']); ?> &nbsp;|&nbsp; <?php echo e($profile['email']); ?></div><div class="company-meta">PAN: <?php echo e($profile['pan']); ?> &nbsp;&nbsp; GST IN: <?php echo e($profile['gst_no']); ?></div></div><div class="rule"></div>
    <?php endif; ?>

    <div class="invoice-title center">TAX INVOICE</div>
    <div class="top-grid">
        <div>
            <div class="meta-line"><span class="label">TAX INVOICE NO.</span><span class="bold"><?php echo e($invoice->bill_no); ?></span></div>
            <div class="meta-line"><span class="label">SO NO.</span><span class="bold"><?php echo e($order?->so_number ?: '-'); ?></span></div>
        </div>
        <div>
            <div class="meta-line"><span class="label">DATE OF INVOICE</span><span class="bold"><?php echo e(optional($invoice->invoice_date)->format('d.m.Y')); ?></span></div>
            <div class="meta-line"><span class="label">PAN</span><span><?php echo e($pan); ?></span></div>
            <div class="meta-line"><span class="label">GST IN</span><span><?php echo e($customer?->gst_no ?: '-'); ?></span></div>
            <div class="meta-line"><span class="label">STATE CODE</span><span><?php echo e($stateCode); ?></span></div>
        </div>
    </div>

    <div class="to-box"><h3>TO</h3><div class="to-name"><?php echo e($customer?->name ?: '-'); ?></div><div style="margin-top:4px;white-space:pre-line"><?php echo e($customer?->address ?: '-'); ?></div><?php if($customer?->phone): ?><div style="margin-top:5px"><b>Phone:</b> <?php echo e($customer->phone); ?></div><?php endif; ?></div>
    <div class="service-box"><b><?php echo e($order?->description ?: 'Transportation Service'); ?></b><br>Transportation from <b><?php echo e($order?->from_location ?: '-'); ?></b> to <b><?php echo e($order?->to_location ?: '-'); ?></b> · <?php echo e($invoice->trip_count); ?> Trip(s)</div>

    <table class="grid">
        <thead><tr><th>Sr</th><th>LR No</th><th>LR Date</th><th>Lorry No</th><th>Vehicle Type</th><th>Transport</th><th class="num">Rate / Trip</th><th class="num">Taxable Amount</th></tr></thead>
        <tbody>
        <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($v=$item->voucher); ?>
            <tr><td class="center"><?php echo e($loop->iteration); ?></td><td><?php echo e($v?->lr_no ?: '-'); ?></td><td><?php echo e(optional($v?->lr_date)->format('d.m.Y')); ?></td><td><?php echo e($v?->lorry_number ?: '-'); ?></td><td><?php echo e($v?->vehicleType?->name ?: '-'); ?></td><td><?php echo e($v?->transportName?->name ?: '-'); ?></td><td class="num"><?php echo e(number_format((float)$item->rate,2)); ?></td><td class="num"><?php echo e(number_format((float)$item->taxable_amount,2)); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <table class="totals">
        <tr><td>Customer Freight</td><td class="num" style="width:180px">₹<?php echo e(number_format((float)$invoice->customer_freight,2)); ?></td></tr>
        <tr><td>GST @ <?php echo e(rtrim(rtrim(number_format((float)$invoice->gst_rate,2,'.',''),'0'),'.')); ?>%</td><td class="num">₹<?php echo e(number_format((float)$invoice->gst_amount,2)); ?></td></tr>
        <tr><td>Total Invoice Amount</td><td class="num bold">₹<?php echo e(number_format((float)$invoice->total_amount,2)); ?></td></tr>
    </table>
    <div class="amount-words">Rupees: <?php echo e($amountWords); ?></div>
    <?php if(($customer?->is_government_employee ?? false) && trim((string)($customer?->bill_note ?? '')) !== ''): ?><div class="customer-bill-note"><?php echo e($customer->bill_note); ?></div><?php endif; ?>

    <table class="gst-summary"><thead><tr><th>GST Rate</th><th class="right">Taxable Amount</th><th class="right">GST Amount</th><th class="right">Invoice Total</th></tr></thead><tbody><tr><td><?php echo e(rtrim(rtrim(number_format((float)$invoice->gst_rate,2,'.',''),'0'),'.')); ?>%</td><td class="right"><?php echo e(number_format((float)$invoice->customer_freight,2)); ?></td><td class="right"><?php echo e(number_format((float)$invoice->gst_amount,2)); ?></td><td class="right bold"><?php echo e(number_format((float)$invoice->total_amount,2)); ?></td></tr></tbody></table>

    <div class="terms-sign"><div class="terms"><h4>TERMS OF PAYMENT</h4><ol><li>Please do not deduct any amount from the bill without our consent.</li><li>Any dispute is subject to local jurisdiction only.</li><li>Payment should quote the invoice number.</li></ol><?php if($invoice->remarks): ?><div style="margin-top:8px"><b>Remarks:</b> <?php echo e($invoice->remarks); ?></div><?php endif; ?><div style="margin-top:10px"><b>Received:</b> ₹<?php echo e(number_format($paid,2)); ?> &nbsp; <b>Balance:</b> ₹<?php echo e(number_format($balance,2)); ?></div></div><div class="signature"><div class="bold">For <?php echo e($profile['name']); ?></div><div class="bold">Authorised Signatory</div></div></div>
    <div class="bank"><b>BANK DETAILS</b><br><b>Name:</b> <?php echo e($profile['bank_holder']); ?><br><b>Bank:</b> <?php echo e($profile['bank_name']); ?><br><b>Address:</b> <?php echo e($profile['bank_address']); ?><br><b>A/C No:</b> <?php echo e($profile['account_no']); ?><br><b>IFSC:</b> <?php echo e($profile['ifsc']); ?></div>
    <div class="footer-note">Supplier freight, supplier payments, Hamali and internal profit are intentionally not shown on the customer tax invoice.</div>
</div>
<script>window.addEventListener('afterprint',()=>{try{parent.postMessage({type:'xyz-invoice-afterprint'},location.origin);}catch(e){}});</script>
</body>
</html>
<?php /**PATH D:\laragon\www\transportsb\resources\views/sale/billing/print.blade.php ENDPATH**/ ?>